package com.example.filedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FileDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
